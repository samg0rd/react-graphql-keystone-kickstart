export { default as config } from '../../../../keystone';
export default function (req, res) {
  return res.status(500);
}
