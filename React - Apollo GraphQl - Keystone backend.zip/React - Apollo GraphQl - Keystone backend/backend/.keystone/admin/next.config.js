// this file is copied somewhere else so this lint rule is incorrect
// eslint-disable-next-line import/no-extraneous-dependencies
module.exports = require('@keystone-next/admin-ui/next-config').config;
